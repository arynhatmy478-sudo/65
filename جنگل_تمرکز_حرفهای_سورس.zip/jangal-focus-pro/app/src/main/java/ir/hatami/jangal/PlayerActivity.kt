package ir.hatami.jangal

import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        playerView = PlayerView(this).apply { layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT); useController = true; setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING) }
        setContentView(FrameLayout(this).apply { addView(playerView) })
        val uri: Uri? = intent.data
        if (uri == null) { finish(); return }
        val prefs = getSharedPreferences("video_positions", MODE_PRIVATE)
        val key = uri.toString()
        val exo = ExoPlayer.Builder(this).build(); player = exo; playerView.player = exo
        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) { if (playbackState == Player.STATE_READY && exo.currentPosition == 0L) { val saved = prefs.getLong(key, 0L); if (saved > 3000L && saved < exo.duration - 3000L) exo.seekTo(saved) } }
        })
        exo.prepare(); exo.playWhenReady = true
    }
    override fun onPause() { player?.let { getSharedPreferences("video_positions", MODE_PRIVATE).edit().putLong(intent.data.toString(), it.currentPosition).apply(); it.pause() }; super.onPause() }
    override fun onDestroy() { playerView.player = null; player?.release(); player = null; super.onDestroy() }
}
