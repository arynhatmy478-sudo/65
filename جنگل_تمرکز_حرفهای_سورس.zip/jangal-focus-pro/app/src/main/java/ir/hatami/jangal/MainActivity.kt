package ir.hatami.jangal

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val videoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; startActivity(Intent(this, PlayerActivity::class.java).setData(it).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
    }
    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; startActivity(Intent(this, PdfActivity::class.java).setData(it).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null); fileCallback = callback
                val intent = params?.createIntent() ?: Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
                try { filePicker.launch(intent) } catch (_: Exception) { fileCallback?.onReceiveValue(null); fileCallback = null; return false }
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.loadUrl("file:///android_asset/index.html")
    }
    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        val uris = if (result.resultCode == Activity.RESULT_OK && data != null) {
            if (data.clipData != null) Array(data.clipData!!.itemCount) { i -> data.clipData!!.getItemAt(i).uri } else data.data?.let { arrayOf(it) }
        } else null
        fileCallback?.onReceiveValue(uris); fileCallback = null
    }
    inner class Bridge {
        @JavascriptInterface fun openNativeVideo() = runOnUiThread { videoPicker.launch(arrayOf("video/*", "application/octet-stream")) }
        @JavascriptInterface fun openNativePdf() = runOnUiThread { pdfPicker.launch(arrayOf("application/pdf")) }
        @JavascriptInterface fun toast(message: String) = runOnUiThread { Toast.makeText(this@MainActivity, message.take(120), Toast.LENGTH_SHORT).show() }
    }
    @Deprecated("Deprecated in Android") override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
}
