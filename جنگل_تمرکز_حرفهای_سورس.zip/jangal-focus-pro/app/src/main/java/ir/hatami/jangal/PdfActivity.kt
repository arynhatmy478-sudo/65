package ir.hatami.jangal

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.IOException

class PdfActivity : AppCompatActivity() {
    private var descriptor: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var pageIndex = 0
    private lateinit var image: ImageView
    private lateinit var label: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent.data ?: run { finish(); return }
        try { descriptor = contentResolver.openFileDescriptor(uri, "r"); renderer = descriptor?.let { PdfRenderer(it) } } catch (_: Exception) { finish(); return }
        image = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.WHITE) }
        label = TextView(this).apply { setTextColor(Color.WHITE); gravity = Gravity.CENTER; textSize = 14f; setPadding(8, 8, 8, 8) }
        val prev = Button(this).apply { text = "قبلی"; setOnClickListener { if (pageIndex > 0) { pageIndex--; renderPage() } } }
        val next = Button(this).apply { text = "بعدی"; setOnClickListener { if (renderer != null && pageIndex < renderer!!.pageCount - 1) { pageIndex++; renderPage() } } }
        val zoomOut = Button(this).apply { text = "−"; setOnClickListener { image.scaleX = (image.scaleX - .15f).coerceAtLeast(.5f); image.scaleY = image.scaleX } }
        val zoomIn = Button(this).apply { text = "+"; setOnClickListener { image.scaleX = (image.scaleX + .15f).coerceAtMost(3f); image.scaleY = image.scaleX } }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; addView(prev); addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); addView(next); addView(zoomOut); addView(zoomIn) }
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.DKGRAY); addView(image) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK); addView(controls); addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)) }
        setContentView(root); renderPage()
    }
    private fun renderPage() {
        val r = renderer ?: return
        try { r.openPage(pageIndex).use { page ->
            val width = (page.width * 1.8f).toInt().coerceIn(500, 2200)
            val height = (page.height.toFloat() / page.width * width).toInt().coerceAtMost(3200)
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888); bitmap.eraseColor(Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); image.setImageBitmap(bitmap)
            label.text = "صفحه ${pageIndex + 1} از ${r.pageCount}"
        } } catch (_: Exception) { label.text = "خطا در نمایش صفحه" }
    }
    override fun onDestroy() { try { renderer?.close(); descriptor?.close() } catch (_: IOException) {}; super.onDestroy() }
}
